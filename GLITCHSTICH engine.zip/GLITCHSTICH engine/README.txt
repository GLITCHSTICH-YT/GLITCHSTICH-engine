# GS Engine

GS Engine is a custom-built game scripting engine developed by Glitchstich in 2025. It uses a lightweight `.gs` format that turns simple, readable commands into fully functional gameplay mechanics using Python and Pygame. No complicated syntax. No clutter. Just clean, human-readable code that powers real-time physics, movement, jumping, collision logic, and more.

This project was built from scratch to simplify 2D game development by letting developers write logic like:
?player1
head > yellow. size = 20px
move. direction: right. rate: 5px. press: right
jump: height = 15px press space

And automatically convert it into working Python-based mechanics.

---

## Features

- 🧠 Custom `.gs` scripting format
- 🕹️ Player movement + directional control
- 🦘 Jump physics
- 🧱 Collision detection
- 🧩 Extendable logic system (e.g., wall-run, push)
- 🐍 Python + Pygame backend

---

## Creator

Made with energy, curiosity, and pure chaos by **Glitchstich** in 2025.  
This engine is the beginning of something big.


