import pygame
import sys
import random

# === read GS script ===
with open(r"C:\Users\b1305\Desktop\GLITCHSTICH engine\mygame.gs", "r") as f:
    lines = [line.strip() for line in f if line.strip()]

players = {}
current_player = None

for line in lines:
    if line.startswith("?"):
        current_player = line[1:].strip()
        players[current_player] = {
            "parts": [],
            "moves": [],
            "jump": None,
            "rect": pygame.Rect(100, 500, 20, 20),
            "y_velocity": 0,
            "is_jumping": False,
            "jump_timer": 0
        }
    elif current_player:
        if "head >" in line or "body >" in line:
            try:
                color = line.split(">")[1].split(".")[0].strip()
                size = int(line.split("size =")[1].split("px")[0])
                part_type = 0 if "head" in line else 1
                players[current_player]["parts"].append((color, size, part_type))
            except:
                pass
        elif "move." in line:
            try:
                direction = line.split("direction:")[1].split(".")[0].strip()
                speed = int(line.split("rate:")[1].split("px")[0])
                key = line.split("press:")[1].split()[-1].upper()
                players[current_player]["moves"].append((direction, speed, key))
            except:
                pass
        elif "jump:" in line:
            try:
                height = int(line.split("height =")[1].split("px")[0])
                key = line.split("press")[1].split()[-1].upper()
                players[current_player]["jump"] = {"height": height, "key": key}
            except:
                pass

# === pygame setup ===
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

key_map = {
    "RIGHT": pygame.K_RIGHT,
    "LEFT": pygame.K_LEFT,
    "SPACE": pygame.K_SPACE
}

# === game loop ===
running = True
while running:
    screen.fill((0, 0, 0))
    keys = pygame.key.get_pressed()

    for pname, pdata in players.items():
        rect = pdata["rect"]

        # Movement
        for direction, speed, key in pdata["moves"]:
            if keys[key_map.get(key, -1)]:
                if direction == "right":
                    rect.x += speed
                elif direction == "left":
                    rect.x -= speed

        # Jump
        if pdata["jump"]:
            jump = pdata["jump"]
            if keys[key_map.get(jump["key"], -1)] and not pdata["is_jumping"]:
                pdata["y_velocity"] = -jump["height"]
                pdata["is_jumping"] = True
                pdata["jump_timer"] = 30

            if pdata["is_jumping"]:
                rect.y += pdata["y_velocity"]
                pdata["y_velocity"] += 1
                pdata["jump_timer"] -= 1
                if pdata["jump_timer"] <= 0:
                    pdata["is_jumping"] = False
                    pdata["y_velocity"] = 0

        # Draw stacked parts
        y = rect.y
        for color, size, part_type in pdata["parts"]:
            pygame.draw.rect(screen, pygame.Color(color), pygame.Rect(rect.x, y, size, size))
            y += size

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
GROUND_LEVEL_Y = 500  # or wherever the spawn point is
WALLS = [pygame.Rect(300, 400, 40, 100)]  # define walls
RUNNABLE_WALLS = [pygame.Rect(600, 300, 40, 200)]  # vertical wall for wall-run

for pname, pdata in players.items():
    rect = pdata["rect"]

    # === Ground Check ===
    if rect.bottom >= GROUND_LEVEL_Y:
        rect.bottom = GROUND_LEVEL_Y
        pdata["is_jumping"] = False
        pdata["y_velocity"] = 0

    # === Wall Collision (Push Animation Trigger) ===
    for wall in WALLS:
        if rect.colliderect(wall):
            pdata["animation"] = "pushing"
            # stop horizontal movement
            if rect.centerx < wall.centerx:
                rect.right = wall.left
            else:
                rect.left = wall.right

    # === Runnable Wall Logic ===
    for rwall in RUNNABLE_WALLS:
        if rect.colliderect(rwall):
            if pdata["is_running"]:  # you'll need to set this on movement keys
                pdata["animation"] = "wall-run"
